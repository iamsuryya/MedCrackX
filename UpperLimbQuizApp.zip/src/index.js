
import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import UpperLimbQuiz from "./UpperLimbQuiz";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <UpperLimbQuiz />
  </React.StrictMode>
);

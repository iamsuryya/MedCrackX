import React, { useState, useEffect } from "react";
import "./index.css";

const questions = [
  {
    question: "Which nerve innervates the thenar muscles of the hand?",
    options: ["Ulnar nerve", "Median nerve", "Radial nerve", "Musculocutaneous nerve"],
    answer: "Median nerve",
    explanation: "The thenar muscles are mainly innervated by the recurrent branch of the median nerve."
  },
  {
    question: "The brachial artery is a continuation of which artery?",
    options: ["Axillary artery", "Subclavian artery", "Radial artery", "Ulnar artery"],
    answer: "Axillary artery",
    explanation: "The axillary artery becomes the brachial artery at the lower border of teres major."
  },
  {
    question: "Which of the following muscles is NOT a flexor of the forearm at the elbow joint?",
    options: ["Biceps brachii", "Brachialis", "Triceps brachii", "Brachioradialis"],
    answer: "Triceps brachii",
    explanation: "Triceps brachii is an extensor of the forearm at the elbow joint."
  },
  {
    question: "The radial nerve passes through which anatomical landmark in the arm?",
    options: ["Cubital fossa", "Radial groove of humerus", "Carpal tunnel", "Axillary sheath"],
    answer: "Radial groove of humerus",
    explanation: "The radial nerve spirals around the humerus in the radial groove."
  },
  {
    question: "What is the primary action of the pronator teres muscle?",
    options: ["Supination of forearm", "Pronation of forearm", "Flexion of wrist", "Extension of wrist"],
    answer: "Pronation of forearm",
    explanation: "Pronator teres pronates the forearm by rotating the radius over the ulna."
  },
  {
    question: "Which artery provides the main blood supply to the lateral aspect of the forearm?",
    options: ["Ulnar artery", "Radial artery", "Brachial artery", "Interosseous artery"],
    answer: "Radial artery",
    explanation: "The radial artery supplies the lateral side of the forearm and hand."
  },
  {
    question: "The palmaris longus tendon inserts into which structure?",
    options: ["Pisiform bone", "Flexor retinaculum and palmar aponeurosis", "Base of 5th metacarpal", "Scaphoid bone"],
    answer: "Flexor retinaculum and palmar aponeurosis",
    explanation: "Palmaris longus inserts into the palmar aponeurosis and helps in grip."
  },
  {
    question: "The ulnar nerve enters the hand through which structure?",
    options: ["Carpal tunnel", "Guyon's canal", "Anatomical snuffbox", "Cubital fossa"],
    answer: "Guyon's canal",
    explanation: "The ulnar nerve enters the hand via Guyon's canal, not the carpal tunnel."
  },
  {
    question: "The flexor digitorum profundus muscle is innervated by which nerves?",
    options: ["Median nerve (all)", "Ulnar nerve (all)", "Median and Ulnar nerves", "Radial nerve"],
    answer: "Median and Ulnar nerves",
    explanation: "FDP is innervated laterally by median and medially by ulnar nerve."
  },
  {
    question: "Which ligament stabilizes the head of the radius against the ulna?",
    options: ["Annular ligament", "Collateral ligament", "Transverse carpal ligament", "Oblique cord"],
    answer: "Annular ligament",
    explanation: "The annular ligament holds the radial head in place during pronation/supination."
  }
];

export default function UpperLimbQuiz() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [shuffled, setShuffled] = useState([]);

  useEffect(() => {
    const shuffledQs = [...questions].sort(() => Math.random() - 0.5);
    setShuffled(shuffledQs);
  }, []);

  const handleOptionClick = (option) => {
    if (!selectedOption) {
      setSelectedOption(option);
      setShowExplanation(true);
    }
  };

  const nextQuestion = () => {
    const nextIndex = (currentIndex + 1) % shuffled.length;
    setCurrentIndex(nextIndex);
    setSelectedOption(null);
    setShowExplanation(false);
  };

  const currentQ = shuffled[currentIndex];
  return (
    <div className="p-4 max-w-xl mx-auto">
      <h2 className="text-xl font-bold mb-4">Question {currentIndex + 1}</h2>
      <p className="mb-4 font-medium">{currentQ.question}</p>
      <ul>
        {currentQ.options.map((opt, i) => (
          <li
            key={i}
            onClick={() => handleOptionClick(opt)}
            className={`p-2 border rounded mb-2 cursor-pointer ${
              selectedOption
                ? opt === currentQ.answer
                  ? "bg-green-200"
                  : opt === selectedOption
                  ? "bg-red-200"
                  : ""
                : "hover:bg-gray-100"
            }`}
          >
            {opt}
          </li>
        ))}
      </ul>
      {showExplanation && (
        <div className="mt-4 p-3 bg-blue-50 border-l-4 border-blue-400">
          <p className="font-semibold">Answer: {currentQ.answer}</p>
          <p>{currentQ.explanation}</p>
        </div>
      )}
      {showExplanation && (
        <button
          onClick={nextQuestion}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
        >
          Next Question
        </button>
      )}
    </div>
  );
}
